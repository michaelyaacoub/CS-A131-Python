''' Programming Exam 3 - Loops
 amT, Spring 2023

Write a program that asks a user to enter a new password 
 Enter a new password that includes at least one of each: 
 lowercase letter, uppercase letter, number and special character.

If the user does not meet the requirements, keeping  asking them.
Once they provide a password that meets the requirements, print
 Thank you, your password has been updated.
'''
"""
Name: Michael Yaacoub
Date: 03/09/23
Assiginment: PE03
"""

renew_passowrd = input("Enter a new password that includes at least one of each: lowercase letter, uppercase letter, number and special character.")
count = 0
i = 0
for i in renew_passowrd :
   if len(renew_passowrd) > 8 and renew_passowrd.upper() and renew_passowrd.lower and renew_passowrd.isdigit and renew_passowrd == '@' :
      print("Thank you, your password has been updated.", end="")
   else :
      renew_passowrd = input("Enter a new password that includes at least one of each: lowercase letter, uppercase letter, number and special character.")
   count+=1
