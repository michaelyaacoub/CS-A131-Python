''' Programming Exam 2 - Decisions
 amT, Spring 2023

 Write a program that prompts a user for a phone number and formats the
 input and prints to the console as:
 (949) 123-4567

 Allow only numbers and dashes "-" BUT only dashes if the input is in this 
 format 949-123-4567.

 If the user includes any other characters print to the console:
 Error

 If the user gives too many or too few numbers print to the console:
 Error.

Examples:
 Enter a phone number:949-456-7890
 (123)456-7890

 Enter a phone number:123456789a
 Error

 You may only use tools up to Chapter 3. You may NOT use loops, lists, etc.
'''

phone_num = input("Enter a phone number:")

if phone_num[0] == '(' and phone_num[4] == ')' and c[4] == '-' and len(phone_num) == 13 :
   print(phone_num)
elif len(phone_num) == 10 :
   print('(' + phone_num[0:3] + ')' + phone_num[3:6] + '-' + phone_num[6:])
elif phone_num[3] == '-' and phone_num[7] == '-' and len(phone_num) == 12 :
   print(phone_num)
else :
   print("Error")

