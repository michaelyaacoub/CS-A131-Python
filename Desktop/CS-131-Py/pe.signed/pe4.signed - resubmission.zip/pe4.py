''' Programming Exam 4 Functions
 amTsaasan, Spring 2023
'''

"""
Name: Michael Yaacoub
Date: 03/16/23
Assiginment: Programming Exam 4 - RESUBMISION
--------------------------------
Write a four (4) functions in alphabetical order,
to be complete a function must include a descriptive
docstring (PEP8 and David Kay's Design Recipe).
The functions must be named:
"""


""" 
- On this function I reviewd my prevuos code and found out my code was not pointing to the correct 
indexes when it was checking for the conditional cases .
- Also I tried to store my return value in an empty string variable and return it instead of printing it.
- I had the wrong assert output so I fixed this by going back to the textbook.

resources:
textbook, PEP8, and an article on Medium expelaining the == vs 'is'.
"""
# def count_types(upper_lower):
#     """Takes in a string and returns a string"""
#     upper_case_letter = 0
#     lower_case_letter = 0
#     for i in range(len(upper_lower)):
#        if upper_lower.isupper() is True:
#             lower_case_letter += 1
#        if lower_lower.lower() is False:
#             upper_case_letter += 1
            
# print(f"There are {upper_case_letter} upper case letters, {lower_case_letter} lower case letters.")

# assert count_types("AAA") == 3
# assert count_types("aaaa") == 4


def count_types(upper_lower):
   """Takes in a string and returns a string"""
   result = ""
   upper_case_letter = 0
   lower_case_letter = 0
   
   for i in range(len(upper_lower)):
      if upper_lower[i].isupper():  #err: Didn't point at the index when checking for isupper() and used wrong operator.
         upper_case_letter += 1
      elif upper_lower[i].islower():   #err: Didn't point at the index when checking for islower() and used wrong operator.
         lower_case_letter += 1
   result = "There are " + str(upper_case_letter) + " upper case letters, " + str(lower_case_letter) + " lower case letters." #err: Didn't store outcome in a var.
   
   return result  #err: return statement didn't exist which function didn't have anything to return and to test.

assert count_types("NEAAWfannncyP@$$word") == "There are 6 upper case letters, 11 lower case letters."  # reformatted result and added expected output
assert count_types("Hello CS Studnetss") == "There are 4 upper case letters, 12 lower case letters."  # reformatted resutl and added expected output



def greeting():
   """Displays the consle"""
   print("Hello World!")


"""
- On this function I spent most of my time reviewing nested loops and the in-class activity we did.
- My main struggle was thinking that I need to print oen line with '-' and another with '|'.
- However, that obvously did not work and my approch changed to printing roof and bottom as x and inside as y.
- I earised the assert statement since the grid() dose not have a return.
- It I was at the end able to trace the test statemnts and print the output without a loop.

resources:
textbook, online tutoring, in-class activity.
"""    
# def grid(integer):
#     """Takes in an int and displays the consle gird"""
#     print("-" * integer)
#     print("| " + " |")
#     print("-" * integer)
    
# assert grid(4) == print("----" * integer)


def grid(integer):
   """Takes in an int and displays the consle gird"""
   print('-' + "---" * integer)  # print roof separated
   print('| ' + '| ' * integer)  # print the inside with proper spacing
   print('-' + "---" * integer)  # print the bottom as the roof
      

"""
- for this function I had an idea on how to solve the problem, however, I didn't have the time.
- I was able to read the error messages and check the test statements.
- I rewrote the whole function with the return value stored in the variable result and return result at the end of the function
- As becoming a fan of having less return statements as peer the textbook.
- I looped through each index of the string to check wether it meets the condition or not.
- I then stored a new string into the result which is initially is an empty string.
- Then returned a new string with the proper format according to the test case.
- Also wrote proper assert statements and fixed indetation.

resources:
textbook, Chaper 3 and 4 review.
"""
# def password_change(string):
#     """ Take in a string param and return it formated per changes"""
#     word = 0
#     result = ""
#     for i in range(len(string)):
#        if string[i] == "a" or if string[i] == "A"
#    return result
   
# assert password_change("aA") == "@"
# assert password_change("iI") == "!"


def password_change(string):
   """ Take in a string param and return it formated per changes"""
   result = ""
   for i in range(len(string)):
      if string[i] == 'A' or string[i] == 'a':
         result = result + '@'   # return the correct output
      elif string[i] == 'I' or string[i] == 'i':   # check for 'I' and 'i'
         result = result + '!'   # return the correct output
      elif string[i] == 'S' or string[i] == 's':   # check for 'S' and 's'
         result = result + '$'   # return the correct output
      else:
         result = result + string[i]   # wrote an else statement as final result
   
   return result # proper indentation
   
assert password_change("a") == "@"  # proper indentation and expected output
assert password_change("I") == "!"  # proper indentation and expected output


