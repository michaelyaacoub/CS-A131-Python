# --------------------------------------
# Name: Michael Yaacoub
# Date: 02/06/2023
# Exercise 1, part C
# --------------------------------------

# sum of odd numbers
sum = 1 + 3 + 5 + 7 + 9

# print out the sum
print(f'The sum of 1, 3, 5, 7, and 9 is {sum}')

# print product of odd numbers
print("The product of 1, 3, 5, 7, and 9 is", 1 * 3 * 5 * 7 * 9)
