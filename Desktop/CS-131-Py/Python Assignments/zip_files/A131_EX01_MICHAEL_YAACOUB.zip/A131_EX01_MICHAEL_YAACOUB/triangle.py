# --------------------------------------
# Name: Michael Yaacoub
# Date: 02/06/2023
# Exercise 1, part B
# --------------------------------------

print("   *   ")
print("  ***  ")
print(" ***** ")
print("*******")
