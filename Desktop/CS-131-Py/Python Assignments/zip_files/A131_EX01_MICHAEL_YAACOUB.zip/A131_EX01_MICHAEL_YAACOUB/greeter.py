# --------------------------------------
# Name: Michael Yaacoub
# Date: 02/06/2023
# Exercise 1, part A
# --------------------------------------

print("Hello World!")
