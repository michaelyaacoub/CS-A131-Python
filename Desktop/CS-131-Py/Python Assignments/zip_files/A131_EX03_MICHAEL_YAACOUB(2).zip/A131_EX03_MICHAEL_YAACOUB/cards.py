"""
---------------------------------------
Name: Michael Yaacoub
Assignment: Ch 03 Exercises - Part A
Date: 02/28/2023
---------------------------------------
Write a program that takes user input describing a poker playing card in the following shorthand notation: first character is the card value, the second character is the card suit.
"""

card_value = input("Enter the first character value of your card: ")

notation = input("Enter the card notation: ")


""" Check for validition first. """
if(notation[-1]!='D' and notation[-1]!='H' and notation[-1]!='S' and notation[-1]!='C'):
    print('Your selection is Invalid')
    quit
elif(notation[:-1]=='A'):
    print('You selected "Ace of ', end='')
elif(notation[:-1]=='2'):
    print('You selected "Two of ', end='')
elif(notation[:-1]=='3'):
    print('You selected "Three of ', end='')
elif(notation[:-1]=='4'):
    print('You selected "Four of ', end='')
elif(notation[:-1]=='5'):
    print('You selected "Five of ', end='')
elif(notation[:-1]=='6'):
    print('You selected "Six of ', end='')
elif(notation[:-1]=='7'):
    print('You selected "Seven of ', end='')
elif(notation[:-1]=='8'):
    print('You selected "Eight of ', end='')
elif(notation[:-1]=='9'):
    print('You selected "Nine of ', end='')
elif(notation[:-1]=='10'):
    print('You selected "Ten of ', end='')
elif(notation[:-1]=='J'):
    print('You selected "Jack of ', end='')
elif(notation[:-1]=='Q'):
    print('You selected "Queen of ', end='')
elif(notation[:-1]=='K'):
    print('You selected "King of ', end='')
else:
    print("Your selection is Invalid! Please select a vaild card.")
    quit


if(notation[-1]=='D'):
    print('Diamonds"')
elif(notation[-1]=='H'):
    print('Hearts"')
elif(notation[-1]=='S'):
    print('Spades"')
elif(notation[-1]=='C'):
    print('Clubs"')


