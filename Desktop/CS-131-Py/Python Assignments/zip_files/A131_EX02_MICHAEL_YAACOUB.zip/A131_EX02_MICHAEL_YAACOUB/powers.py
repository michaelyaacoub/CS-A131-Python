# --------------------------------------
# Name: Michael Yaacoub
# Date: 02/08/2023
# Exercise 2, part C
# --------------------------------------

print(f'6 squared is {6 * 6}')      # Print 6 squared
print(f'6 cubed is {6 * 6 * 6}')    # Print 6 cubed
print(f'6 to the fourth power is {6 ** 4}') # Print 6 to 4th pow
